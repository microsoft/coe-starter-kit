## Power Platform Hub template

The Power Platform Hub template is a SharePoint communication site designed to provide you with a starting point of content and page templates as you're setting up your internal Power Platform wiki and hub site. This communication site is designed to be the place where your Power Platform community can find the news and resources they need, including digital governance and compliance guardrails, upcoming events, success stories and more.

Learn more about how to deploy and use the template:
https://learn.microsoft.com/power-platform/guidance/adoption/wiki-community

